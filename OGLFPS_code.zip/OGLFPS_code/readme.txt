环境配置
以 Windows10 操作系统为例，请把代码文件根目录中“freeglut.dll”文件与 “glew32.dll”文件，放到运行游戏的电脑的 C:\Windows\System 目录下。
（如需管理员权限，请允许）