/*
#include<GL/glew.h>

#include<vector>

#include"CAP_file.h"
*/
namespace CAP
{

namespace GLSL
{
class Program;
class Shader;

class Program
{
	private:
		GLuint programHandle;
	public:
		Program();
		explicit Program(GLuint);
		
		inline bool isZero()const;
		int activeAttributes(bool,const char* const)const;
		int activeUniforms(bool,const char* const)const;
		int attachedShaders()const;
		inline int create();
		int deleteStatus()const;
		int linkStatus(bool,const char* const)const;
		inline void attachShader(GLuint)const;
		inline void attachShader(const Shader&)const;
		inline void deletion()const;
		inline void detachShader(GLuint)const;
		inline void detachShader(const Shader&)const;
		inline void link()const;
		inline void use()const;
		
		void set(GLuint value){programHandle=value;}
		GLuint get()const{return programHandle;}
};

class Shader
{
	private:
		GLuint shaderHandle;
	public:
		Shader();
		explicit Shader(int);
		explicit Shader(const char* const,int);
		
		inline bool isZero()const;
		int compile(const char* const)const;
		int compileStatus(bool,const char* const)const;
		inline int create(int);
		int deleteStatus()const;
		int shaderType()const;
		inline void deletion()const;
		
		void set(GLuint value){shaderHandle=value;}
		GLuint get()const{return shaderHandle;}
};

GLuint bindBufferData(GLenum,GLsizeiptr,const GLvoid*,GLenum);



//Program
Program::Program():
	programHandle(0)
{}
Program::Program(GLuint ph):
	programHandle(ph)
{}

inline bool Program::isZero()const{return programHandle==0;}
int Program::activeAttributes(bool print=false,const char* const path=0)const
{
	int location=0,maxLength=0,n=0,size=0,written=0,
		i=0;
	FILE *fp=0;
	GLenum type=0;
	
	glGetProgramiv(programHandle,GL_ACTIVE_ATTRIBUTES,&n);
	if(!print){return n;}
	if(n<=0){return n;}

	glGetProgramiv(programHandle,GL_ACTIVE_ATTRIBUTE_MAX_LENGTH,&maxLength);
	std::vector<char> attribute(maxLength+1);
	attribute[maxLength]='\0';
	if(path==0){printf("location attribute written size type\n");}
	else
	{
		fp=fopen(path,"ab");
		if(fp==0){return n;}
		
		fprintf(fp,"location attribute written size type\n");
	}
	for(i=0;i< n;i++)
	{
		glGetActiveAttrib(programHandle,i,maxLength,&written,&size,&type,&attribute[0]);
		location=glGetAttribLocation(programHandle,&attribute[0]);
		if(path==0){printf("%d %s %d %d %d\n", location,&attribute[0],written,size,type);}
		else{fprintf(fp,"%d %s %d %d %d\n", location,&attribute[0],written,size,type);}
	}
	
	if(path!=0){fclose(fp);}
	return n;
}
int Program::activeUniforms(bool print=false,const char* const path=0)const
{
	int location=0,maxLength=0,n=0,size=0,written=0,
		i=0;
	FILE *fp=0;
	GLenum type=0;
	
	glGetProgramiv(programHandle,GL_ACTIVE_UNIFORMS,&n);
	if(!print){return n;}
	if(n<=0){return n;}
	
	glGetProgramiv(programHandle,GL_ACTIVE_UNIFORM_MAX_LENGTH,&maxLength);
	std::vector<char> uniform(maxLength+1);
	uniform[maxLength]='\0';
	if(path==0){printf("location uniform written size type\n");}
	else
	{
		fp=fopen(path,"ab");
		if(fp==0){return n;}
		
		fprintf(fp,"location uniform written size type\n");
	}
	for(i=0;i< n;i++)
	{
		glGetActiveUniform(programHandle,i,maxLength,&written,&size,&type,&uniform[0]);
		location=glGetUniformLocation(programHandle,&uniform[0]);
		if(path==0){printf("%d %s %d %d %d\n",location,&uniform[0],written,size,type);}
		else{fprintf(fp,"%d %s %d %d %d\n",location,&uniform[0],written,size,type);}
	}
	
	if(path!=0){fclose(fp);}
	return n;
}
int Program::attachedShaders()const
{
	int status=0;
	glGetProgramiv(programHandle,GL_ATTACHED_SHADERS,&status);
	return status;
}
inline int Program::create()
{
	programHandle=glCreateProgram();
	return programHandle;
}
int Program::deleteStatus()const
{
	int status=0;
	glGetProgramiv(programHandle,GL_DELETE_STATUS,&status);
	return status;
}
int Program::linkStatus(bool print=false,const char* const path=0)const
{
	int length=0,status=0,written=0;
	
	glGetProgramiv(programHandle,GL_LINK_STATUS,&status);
	if(status==GL_FALSE && print)
	{
		glGetProgramiv(programHandle,GL_INFO_LOG_LENGTH,&length);
		if(0< length)
		{
			std::vector<char> log(length+1);
			glGetProgramInfoLog(programHandle,length,&written,&log[0]);
			log[length]='\0';
			if(path==0){fprintf(stderr,"Program link log:\n%s\n", &log[0]);}
			else
			{
				CAP_appendFile(path,"Program link log:\n");
				CAP_appendFile(path,&log[0]);
				CAP_appendFile(path,"\n");
			}
		}
	}
	
	return status;
}
inline void Program::attachShader(GLuint shaderHandle)const{glAttachShader(programHandle,shaderHandle);}
inline void Program::attachShader(const Shader& shader)const{glAttachShader(programHandle,shader.get());}
inline void Program::deletion()const{glDeleteProgram(programHandle);}
inline void Program::detachShader(GLuint shaderHandle)const{glDetachShader(programHandle,shaderHandle);}
inline void Program::detachShader(const Shader& shader)const{glDetachShader(programHandle,shader.get());}
inline void Program::link()const
{if(programHandle!=0){glLinkProgram(programHandle);}}
inline void Program::use()const
{if(programHandle!=0){glUseProgram(programHandle);}}

//Shader
Shader::Shader():
	shaderHandle(0)
{}
Shader::Shader(int mode):
	shaderHandle(glCreateShader(mode))
{}
Shader::Shader(const char* const path,int mode):
	shaderHandle(glCreateShader(mode))
{compile(path);}

inline bool Shader::isZero()const{return shaderHandle==0;}
int Shader::compile(const char* const path)const
{
	char *codeArray[1]={0};
	
	if(shaderHandle==0 || path==0){return 1;}
	
	codeArray[0]=CAP_readFile(path);
	if(codeArray[0]==0){return 1;}
	
	glShaderSource(shaderHandle,1,codeArray,NULL);
	glCompileShader(shaderHandle);
	
	free(codeArray[0]);
	return 0;
}
int Shader::compileStatus(bool print=false,const char* const path=0)const
{
	int length=0,status=0,written=0;
	
	glGetShaderiv(shaderHandle,GL_COMPILE_STATUS,&status);
	if(status==GL_FALSE && print)
	{
		glGetShaderiv(shaderHandle,GL_INFO_LOG_LENGTH,&length);
		if(0< length)
		{
			std::vector<char> log(length+1);
			glGetShaderInfoLog(shaderHandle,length,&written,&log[0]);
			log[length]='\0';
			if(path==0){fprintf(stderr,"Shader compile log:\n%s\n", &log[0]);}
			else
			{
				CAP_appendFile(path,"Shader compile log:\n");
				CAP_appendFile(path,&log[0]);
				CAP_appendFile(path,"\n");
			}
		}
	}
	
	return status;
}
inline int Shader::create(int mode)
{
	shaderHandle=glCreateShader(mode);
	return shaderHandle;
}
int Shader::deleteStatus()const
{
	int status=0;
	glGetShaderiv(shaderHandle,GL_DELETE_STATUS,&status);
	return status;
}
int Shader::shaderType()const
{
	int status=0;
	glGetShaderiv(shaderHandle,GL_SHADER_TYPE,&status);
	return status;
}
inline void Shader::deletion()const{glDeleteShader(shaderHandle);}



//function
GLuint bindBufferData(GLenum BUFFER_TARGET,GLsizeiptr size,const GLvoid* data,GLenum DATA_USAGE)
{
	GLuint bufferHandle;
	glGenBuffers(1,&bufferHandle);
	glBindBuffer(BUFFER_TARGET,bufferHandle);
	glBufferData(BUFFER_TARGET,size,data,DATA_USAGE);
	return bufferHandle;
}

}

}
